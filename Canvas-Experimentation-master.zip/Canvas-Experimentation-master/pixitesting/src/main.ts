import "./style.css";
import * as PIXI from "pixi.js";
import { Viewport } from "pixi-viewport";

const mainContainer: HTMLElement = document.querySelector<HTMLElement>(`#app`)!;
console.log(mainContainer);

let app = new PIXI.Application({
  backgroundColor: 0x808080,
  width: mainContainer?.clientWidth,
  height: mainContainer?.clientHeight,
  resizeTo: mainContainer,
});

mainContainer?.appendChild(app.view);

const viewport = new Viewport({
  screenWidth: mainContainer?.clientWidth,
  screenHeight: mainContainer?.clientHeight,
  worldWidth: 10000,
  worldHeight: 10000,
  passiveWheel: false,

  interaction: app.renderer.plugins.interaction, // the interaction module is important for wheel to work properly when renderer.view is placed or scaled
});

app.stage.addChild(viewport);
console.log(viewport);
let sprite = PIXI.Sprite.from(
  "https://s3.amazonaws.com/appforest_uf/d110/f1666789959064x687426450955901360/7a0063a2a1421bd321bc5499f10b096218470067c61aff5ff7fac0ec780310e3"
);
viewport.addChild(sprite);

sprite.position.set(viewport.worldWidth / 2, viewport.worldHeight / 4);
sprite.interactive = true;
sprite.addListener(`pointerdown`, (e) => {
  console.log(e);
});
viewport.pinch().wheel().drag();

viewport.clampZoom({
  maxScale: 3,
  minScale: 0.01,
});
const line = viewport.addChild(new PIXI.Graphics());
line
  .lineStyle(100, 0xff0000)
  .drawRect(0, 0, viewport.worldWidth, viewport.worldHeight);
viewport.fit();
document.body.style.cursor = "grab";

let pressingMouse = false;
let startingMouseX = 0;
let startingMouseY = 0;

let drawingSq = new PIXI.Graphics();

viewport.on("pointerdown", (e) => {
  console.log(e);

  console.log(viewport);
  viewport.drag({ pressDrag: false });
  pressingMouse = true;

  viewport.addChild(drawingSq);
  drawingSq.beginFill(0xffffff);
  drawingSq.drawRect(startingMouseX - 10, startingMouseY - 10, 10, 10);
});
window.addEventListener("pointerup", () => {
  pressingMouse = false;
  viewport.drag({ pressDrag: true });
});

viewport.on(`pointermove`, (e) => {
  if (pressingMouse && e.data.global.x > 0) {
    drawingSq.clear();
    console.log(`cleared`);
    console.log();

    drawingSq.beginFill(0xffffff);
    drawingSq.drawRect(
      startingMouseX - 10,
      startingMouseY - 10,
      e.data.global.x - startingMouseX,
      e.data.global.y - startingMouseY
    );
  }
});
